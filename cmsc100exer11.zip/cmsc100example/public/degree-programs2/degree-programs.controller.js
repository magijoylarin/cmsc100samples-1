// degree-programs/degree-programs.controller.js

'use strict';

(function(){
	angular
		.module("app")
		.controller("DegreeProgramsCtrl", DegreeProgramsCtrl);

	DegreeProgramsCtrl.$inject = ["$scope", "DegreeProgramsService"];

	function DegreeProgramsCtrl($scope, DegreeProgramsService) {
		$scope.degreePrograms=[];

		DegreeProgramsService.GetAll()
			.then(function(data) {
				$scope.degreePrograms = data;
			});

		$scope.AddDegreeProgram = function(){
			DegreeProgramsService.AddDegreeProgram($scope.newDegreeProgram)
				.then(function(data) {
					$scope.newDegreeProgram.code = "";
					$scope.newDegreeProgram.name = "";
					$scope.degreePrograms.push(data);
				});
		}

		$scope.DelDegreeProgram = function(){
			DegreeProgramsService.DelDegreeProgram($scope.oldDegreeProgram)
				.then(function(data) {
					index = $scope.oldDegreeProgram.id;
					if (index > -1) {
					    degreePrograms.splice(5, 1);
					}

					$scope.oldDegreeProgram.id = "";
					//$scope.degreePrograms.push(data);
				});
		}

		$scope.UpdDegreeProgram = function(){
			DegreeProgramsService.UpdDegreeProgram($scope.updDegreeProgram)
				.then(function(data) {
					$scope.updDegreeProgram.code = "";
					$scope.updDegreeProgram.name = "";
					$scope.degreePrograms.push(data);
				});
		}

		$scope.RetDegreeProgram = function(){
			DegreeProgramsService.RetDegreeProgram($scope.retDegreeProgram)
				.then(function(data) {
					$scope.retDegreeProgram.id = "";
				});
		}
	}
})();